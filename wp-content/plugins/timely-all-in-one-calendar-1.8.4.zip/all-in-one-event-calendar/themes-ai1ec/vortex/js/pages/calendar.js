timely.require( 
		[ "themes/vortex/calendar" ], 
		function( page ) {
			page.start();
		}
);