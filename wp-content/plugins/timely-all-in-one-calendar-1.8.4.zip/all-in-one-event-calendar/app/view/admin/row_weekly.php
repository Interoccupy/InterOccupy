<div class="ai1ec_repeat_centered_content">
  <label for="ai1ec_weekly_count">
	  <?php _e( 'Every', AI1EC_PLUGIN_NAME ) ?>:
  </label>
  <?php echo $count ?>
  <label><?php _ex( 'On', 'Recurrence editor - weekly tab', AI1EC_PLUGIN_NAME ) ?>:</label>
  <div style="clear: both;"></div>
  <?php echo $week_days ?>
</div>