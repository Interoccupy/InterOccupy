<div id="message" class="alert alert-error"><strong><?php echo esc_html( _X( $message, 'calendar-feeds', AI1EC_PLUGIN_NAME ) )?></strong></div>

