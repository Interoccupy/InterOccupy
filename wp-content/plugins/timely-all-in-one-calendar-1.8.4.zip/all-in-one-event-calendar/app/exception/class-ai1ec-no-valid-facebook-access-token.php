<?php
/**
 * @author time.ly
 *
 *
 */
class Ai1ec_No_Valid_Facebook_Access_Token extends Exception {
}
?>
