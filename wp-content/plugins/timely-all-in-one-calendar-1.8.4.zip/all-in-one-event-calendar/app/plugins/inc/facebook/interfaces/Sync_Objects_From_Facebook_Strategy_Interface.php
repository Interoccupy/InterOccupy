<?php

/**
*
*/

interface Sync_Objects_From_Facebook_Strategy_Interface {
	
	public function get_users_from_facebook( Facebook_WP_Extend_Ai1ec $facebook );
	
}

?>