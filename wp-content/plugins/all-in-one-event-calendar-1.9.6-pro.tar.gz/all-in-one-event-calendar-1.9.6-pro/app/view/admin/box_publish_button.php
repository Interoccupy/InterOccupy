<input type="button" 
			 name="ai1ec_bottom_publish" 
			 id="ai1ec_bottom_publish" 
			 class="button-primary ai1ec_bottom_publish" 
			 value="<?php echo $button_value ?>" />