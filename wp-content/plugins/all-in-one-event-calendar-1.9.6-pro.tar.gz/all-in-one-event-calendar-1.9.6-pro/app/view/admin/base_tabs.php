<div class="tabbable <?php echo $class; ?>">
	<ul class="nav nav-tabs">
		<?php $component->render_headers(); ?>
	</ul>
	<div class="tab-content">
		<?php $component->render_bodies(); ?>
	</div>
</div>
