<?php
/**
 * @author time.ly
 *
 *
 */
class Ai1ec_Error_Validating_App_Id_And_Secret extends Exception {
}
