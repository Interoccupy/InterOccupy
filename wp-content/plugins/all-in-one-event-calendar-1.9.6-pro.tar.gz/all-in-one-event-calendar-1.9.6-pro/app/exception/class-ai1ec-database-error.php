<?php
//
//  class-ai1ec-database-error.php
//  all-in-one-event-calendar
//
//  Created by The Seed Studio on 2012-11-07.
//

/**
 * Ai1ec_Database_Error class
 *
 * @package Exceptions
 * @author  Timely Network Inc
 **/
class Ai1ec_Database_Error extends Exception
{
}
