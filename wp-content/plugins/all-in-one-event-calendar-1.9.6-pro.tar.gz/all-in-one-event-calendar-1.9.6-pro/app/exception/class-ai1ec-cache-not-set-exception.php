<?php

/**
 * @author Timely Network Inc
 *
 *
 */

class Ai1ec_Cache_Not_Set_Exception extends Exception {

}
