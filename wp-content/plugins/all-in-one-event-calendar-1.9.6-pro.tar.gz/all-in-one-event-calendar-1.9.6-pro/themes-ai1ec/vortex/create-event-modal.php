<div class="modal hide fade" id="ai1ec-create-event-modal">
	<div class="ai1ec-loading show"></div>
	<div class="ai1ec-ajax-placeholder">
		<!-- Form content is loaded here via AJAX. -->
	</div>
</div>
