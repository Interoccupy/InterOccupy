<div class="btn-group">
	<a id="ai1ec-agenda-collapse-all" class="btn btn-mini">
		<i class="icon-minus-sign"></i> <?php _e( 'Collapse All', AI1EC_PLUGIN_NAME ) ?>
	</a>
	<a id="ai1ec-agenda-expand-all" class="btn btn-mini">
		<i class="icon-plus-sign"></i> <?php _e( 'Expand All', AI1EC_PLUGIN_NAME ) ?>
	</a>
</div><div class="btn-group">
<a id="ai1ec-print-button" href="#" class="btn">
	<i class="icon-print"></i>
</a>
</div><?php // Required to ensure no trailing whitespace.
