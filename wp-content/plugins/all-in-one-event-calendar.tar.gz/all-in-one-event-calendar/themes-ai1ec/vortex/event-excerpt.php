<div class="timely ai1ec-excerpt">
	<div class="ai1ec-time"><span class="ai1ec-label"><?php _e( 'When:', AI1EC_PLUGIN_NAME ) ?></span> <?php echo $event->timespan_html ?></div>
	<?php if( $location ): ?>
		<div class="ai1ec-location"><span class="ai1ec-label"><?php _e( 'Where:', AI1EC_PLUGIN_NAME ) ?></span> <?php echo $location ?></div>
	<?php endif ?>
</div>
